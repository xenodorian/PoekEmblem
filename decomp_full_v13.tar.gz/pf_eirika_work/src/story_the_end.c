#include "global.h"
#include "gpu_regs.h"
#include "bg.h"
#include "main.h"
#include "palette.h"
#include "sprite.h"
#include "task.h"
#include "scanline_effect.h"
#include "overworld.h"
#include "script.h"
#include "constants/songs.h"
#include "sound.h"

// THE END title card shown after the chapter 22 epilogue. Graphics come from tools/leg10_the_end_card.py.
static const u16 sStoryEnd_Pal[] = INCBIN_U16("graphics/story_end/the_end_card.gbapal");
static const u32 sStoryEnd_Tiles[] = INCBIN_U32("graphics/story_end/the_end_card.4bpp");
static const u16 sStoryEnd_Map[] = INCBIN_U16("graphics/story_end/the_end_card.bin");

static const struct BgTemplate sStoryEnd_BgTemplates[] = {
    {
        .bg = 0,
        .charBaseIndex = 0,
        .mapBaseIndex = 28,
        .screenSize = 0,
        .paletteMode = FALSE,
        .priority = 0,
        .baseTile = 0
    }
};

static u16 sStoryEndTimer;
static u8 sStoryEndState;

static void StoryEnd_VBlank(void)
{
    LoadOam();
    ProcessSpriteCopyRequests();
    TransferPlttBuffer();
}

static void CB2_StoryTheEnd(void)
{
    switch (sStoryEndState)
    {
    case 0:
        SetVBlankCallback(NULL);
        SetHBlankCallback(NULL);
        SetGpuReg(REG_OFFSET_DISPCNT, 0);
        SetGpuReg(REG_OFFSET_BLDCNT, 0);
        SetGpuReg(REG_OFFSET_BLDALPHA, 0);
        SetGpuReg(REG_OFFSET_BLDY, 0);
        ResetPaletteFade();
        ResetSpriteData();
        ResetTasks();
        ResetBgsAndClearDma3BusyFlags(0);
        InitBgsFromTemplates(0, sStoryEnd_BgTemplates, ARRAY_COUNT(sStoryEnd_BgTemplates));
        ChangeBgX(0, 0, BG_COORD_SET);
        ChangeBgY(0, 0, BG_COORD_SET);
        LoadBgTiles(0, sStoryEnd_Tiles, sizeof(sStoryEnd_Tiles), 0);
        CopyToBgTilemapBuffer(0, sStoryEnd_Map, sizeof(sStoryEnd_Map), 0);
        LoadPalette(sStoryEnd_Pal, BG_PLTT_ID(0), sizeof(sStoryEnd_Pal));
        CopyBgTilemapBufferToVram(0);
        SetVBlankCallback(StoryEnd_VBlank);
        sStoryEndState++;
        break;
    case 1:
        SetGpuReg(REG_OFFSET_DISPCNT, DISPCNT_MODE_0 | DISPCNT_OBJ_1D_MAP | DISPCNT_BG0_ON);
        ShowBg(0);
        BeginNormalPaletteFade(PALETTES_ALL, 4, 16, 0, RGB_BLACK);
        sStoryEndTimer = 0;
        sStoryEndState++;
        break;
    case 2:
        if (!gPaletteFade.active)
            sStoryEndState++;
        break;
    case 3:
        // hold the card, then leave on A or B, or by itself after about 12 seconds
        sStoryEndTimer++;
        if ((JOY_NEW(A_BUTTON | B_BUTTON) && sStoryEndTimer > 60) || sStoryEndTimer > 720)
        {
            BeginNormalPaletteFade(PALETTES_ALL, 4, 0, 16, RGB_BLACK);
            sStoryEndState++;
        }
        break;
    case 4:
        if (!gPaletteFade.active)
        {
            sStoryEndState++;
        }
        break;
    default:
        SetMainCallback2(CB2_ReturnToFieldContinueScriptPlayMapMusic);
        break;
    }
    RunTasks();
    AnimateSprites();
    BuildOamBuffer();
    UpdatePaletteFade();
}

void ShowStoryTheEnd(void)
{
    sStoryEndState = 0;
    sStoryEndTimer = 0;
    SetMainCallback2(CB2_StoryTheEnd);
    ScriptContext_Stop();
}
