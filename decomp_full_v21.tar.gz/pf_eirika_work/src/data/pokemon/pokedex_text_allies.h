// Pokedex text for Eirika and the 8 allies (original wording, plain FE8 flavor)
const u8 gInnesPokedexText[] = _(
    "Crown prince of Frelia and a sniper\n"
    "with no equal. He is calm and proud,\n"
    "and he guards his sister Tana.");

const u8 gInnesPokedexTextUnused[] = _("");

const u8 gTanaPokedexText[] = _(
    "A pegasus knight of Frelia and\n"
    "Innes's younger sister. She is\n"
    "bright and quick, and loves to fly.");

const u8 gTanaPokedexTextUnused[] = _("");

const u8 gLArachelPokedexText[] = _(
    "A Rausten princess who wields a\n"
    "staff and a loud voice. She thinks\n"
    "she is a hero and acts like one.");

const u8 gLArachelPokedexTextUnused[] = _("");

const u8 gDozlaPokedexText[] = _(
    "A strong axe fighter of Jehanna.\n"
    "He looks fierce but is kind, and\n"
    "he never leaves a friend behind.");

const u8 gDozlaPokedexTextUnused[] = _("");

const u8 gJoshuaPokedexText[] = _(
    "A swordsman from Jehanna. He lives\n"
    "by the dice and wins more than\n"
    "he loses, with a blade or a bet.");

const u8 gJoshuaPokedexTextUnused[] = _("");

const u8 gDuesselPokedexText[] = _(
    "Once the Silver Axe of Grado. A\n"
    "loyal and serious knight who left\n"
    "the empire to keep his honor.");

const u8 gDuesselPokedexTextUnused[] = _("");

const u8 gCormagPokedexText[] = _(
    "A wyvern rider of Grado who chose\n"
    "to leave the empire. He is quiet,\n"
    "steady and loyal to his friends.");

const u8 gCormagPokedexTextUnused[] = _("");

const u8 gMyrrhPokedexText[] = _(
    "A young manakete who can turn into\n"
    "a dragon. She is shy and gentle,\n"
    "and she is always hungry.");

const u8 gMyrrhPokedexTextUnused[] = _("");

const u8 gEirikaPokedexText[] = _(
    "Princess of Renais and twin sister\n"
    "of Ephraim. She wields a rapier and\n"
    "leads the march to save the land.");

const u8 gEirikaPokedexTextUnused[] = _("");

